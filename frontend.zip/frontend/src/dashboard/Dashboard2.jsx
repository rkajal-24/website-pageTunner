// import React from 'react'

import { HiUser } from "react-icons/hi"
import { MdBook } from 'react-icons/md'; 
import { FaStar } from 'react-icons/fa';
import { Link } from "react-router-dom"

const Dashboard2 = () => {
  return (
    <>
    {/* Main content */}
    <div className="flex-1 bg-gray-100 py-6 px-4 lg:px-10 xl:px-16">

      {/* user status bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    <div className="bg-white p-6 rounded-lg shadow-lg mb-4 ">
        <h3 className="text-xl font-semibold mb-2">Experience</h3>
        <p>2.4k</p>
        <div className="flex justify-between gap-14">
        <p className="text-gray-600">USERS</p>
        <MdBook className="text-blue-500 text-2xl" />
        </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg mb-4">
        <h3 className="text-xl font-semibold mb-2">Sales</h3>
        <p>1400 Book Sell</p>
        <div className="flex justify-between gap-14">
        <p className="text-gray-600">Purchase</p>
        <HiUser className="text-blue-500 text-2xl" />
        </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-lg mb-4">
        <h3 className="text-xl font-semibold mb-2">Rewiews</h3>
        <p>500</p>
        <div className="flex justify-between gap-14">
        <p className="text-gray-600">USERS Rewiews</p>
        <FaStar className="text-blue-500 text-2xl" />
        </div>
        </div>
        
      </div>
    {/* Main content area */}
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">


      {/* Book Management */}
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h3 className="text-xl font-semibold mb-2">Book Management</h3>
        <p className="text-gray-600">Manage your book inventory, add new books, update book details, and remove outdated titles.</p>
        <Link to="/admin/dashboard/manage" className="block"><button className="mt-4 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">Manage Books</button></Link>
      </div>
      
      {/* Sales Analytics */}
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h3 className="text-xl font-semibold mb-2">Sales Analytics</h3>
        <p className="text-gray-600">Track sales performance, view revenue trends, and analyze customer buying behavior.</p>
        <button className="mt-4 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">View Analytics</button>
      </div>
      
      
      {/* Customer Engagement */}
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h3 className="text-xl font-semibold mb-2">Customer Engagement</h3>
        <p className="text-gray-600">Interact with customers, respond to inquiries, and provide personalized recommendations.</p>
        <button className="mt-4 bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600">Engage Customers</button>
      </div>
      </div>
      <div className="bg-white p-6 mt-5 rounded-lg shadow-lg">
        <h3 className="text-xl font-semibold mb-2">Book Selling Graph</h3>
        <p className="text-gray-600">Interact with customers, respond to inquiries, and provide personalized recommendations.</p>
        <img src="https://www.pinclipart.com/picdir/big/61-619035_graph-png-download-image-clip-art-transparent-stock.png" alt="" />
        
      </div>
    
  </div>
  </>
    
  )
}

export default Dashboard2
