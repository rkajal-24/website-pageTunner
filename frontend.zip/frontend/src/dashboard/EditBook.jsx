// import React, { useState } from 'react';
import { useParams, useLoaderData, useLocation, useNavigate } from 'react-router-dom';
import { Button, Label, TextInput, Textarea } from 'flowbite-react';
import { useState } from 'react';

const EditBook = () => {
  const { id } = useParams();
  const {bookTitle, authorName, imageURL, bookDescription, shoplink, readlink} = useLoaderData();

  const bookCategory = [
    "Fiction", 
    "Non-Fiction", 
    "Mystery", 
    "Programming", 
    "Horror",
    "Science Fiction",
    "Fantasy", 
    "Bibliography", 
    "Autobiography",
    "History",
    "LGBTQ+",
    "Romance",
    "Novels",
    "Manga",
    "Sports", 
    "Self-help", 
    "Business", 
    "Education", 
    "Children Books",
    "Travel", 
    "Religion", 
    "Art and Design"
  ];

  const [selectedBookCategory, setSelectedBookCategory] = useState(bookCategory[0]);

  const handleChangeSelectedValue = (e) => {
    setSelectedBookCategory(e.target.value);
  }
  const location = useLocation();
    const navigate = useNavigate();
    
  const handleUpdate = (e) => {
    e.preventDefault();
    const form = e.target;

    const bookTitle = form.bookTitle.value;
    const authorName = form.authorName.value;
    const imageURL = form.imageURL.value;
    const category = form.categoryName.value;
    const bookDescription = form.bookDescription.value;
    const shoplink = form.shoplink.value;
    const readlink = form.readlink.value;

    const UpdatebBookObj = {
      bookTitle, authorName, imageURL, category, bookDescription, shoplink, readlink
    };

    const from = location.state?.from?.pathname || "/admin/dashboard/manage";
    // update book data    book/:id
    fetch(`http://localhost:5000/book/${id}`, {
      method: "PATCH",
      headers: {
        "Content-type": "application/json"
      },
      body: JSON.stringify(UpdatebBookObj)
    })
    .then(res => res.json())
    .then(data => {
      console.log(data);
      alert("Book Updated Successfully...");
      navigate(from, { replace: true });
      // Reset the form
      //form.reset();
    })
    .catch(error => {
      console.error('Error:', error);
      alert("Failed to upload book. Please try again later.");
    });

    
  }

  return (
    <div className="px-4 my-12">
      <h2 className="mb-8 text-3xl font-bold">Update the Book data</h2>

      <form onSubmit={handleUpdate} className="flex lg:w-[1180px] flex-col flex-wrap gap-4">
        <div className="flex gap-8">
          <div className="lg:w-1/2">
            <div className="mb-2 block">
              <Label htmlFor="bookTitle" value="Book Title" />
            </div>
            <TextInput id="bookTitle" name="bookTitle" type="text" placeholder="Book Name" required defaultValue={bookTitle} />
          </div>
          <div className="lg:w-1/2">
            <div className="mb-2 block">
              <Label htmlFor="authorName" value="Book Author" />
            </div>
            <TextInput id="authorName" name="authorName" type="text" placeholder="Author Name" required defaultValue={authorName} />
          </div>
        </div>

        <div className="flex gap-8">
          <div className="lg:w-1/2">
            <div className="mb-2 block">
              <Label htmlFor="imageURL" value="Book Image URL" />
            </div>
            <TextInput id="imageURL" name="imageURL" type="text" placeholder="Book Image URL" required defaultValue={imageURL} />
          </div>
          <div className="lg:w-1/2">
            <div className="mb-2 block">
              <Label htmlFor="inputState" value="Book Category" />
            </div>
            <select name="categoryName" id="inputState" className="w-full rounded" value={selectedBookCategory} onChange={handleChangeSelectedValue}>
              {bookCategory.map(option => <option key={option} value={option}>{option}</option>)}
            </select>
          </div>
        </div>

        <div>
          <div className="mb-2 block">
            <Label htmlFor="bookDescription" value="Book Description..." />
          </div>
          <Textarea id="bookDescription" name="bookDescription" placeholder="Book Description" className="w-full" rows={6} defaultValue={bookDescription} required/>
        </div>

        <div className="flex gap-8">
          <div className="lg:w-1/2">
            <div className="mb-2 block">
              <Label htmlFor="shoplink" value="Shopping Link" />
            </div>
            <TextInput id="shoplink" name="shoplink" type="text" placeholder="Shopping Link" required defaultValue={shoplink} />
          </div>
          <div className="lg:w-1/2">
            <div className="mb-2 block">
              <Label htmlFor="readlink" value="Read Link" />
            </div>
            <TextInput id="readlink" name="readlink" type="text" placeholder="Online reading link" required defaultValue={readlink}/>
          </div>
        </div>

        <Button type="submit" className="mt-5">
          Update Book
        </Button>
      </form>
    </div>
  );
}

export default EditBook;
