// import React from 'react'
import { Outlet } from 'react-router-dom'
import SideBarElement from './SideBarElement'



// dashboardlayout
const Dashboard = () => {
  return (
    <div className='flex gap-4 flex-col md:flex-row'>
      <SideBarElement/>
     <Outlet/>
    </div>
  )
}

export default Dashboard
