// import React from 'react'
import {Button, Label, TextInput, Textarea } from "flowbite-react";
import { useState } from "react";

const UploadBook = () => {
const bookCategory = [
  "Fiction",
  "Non-Fiction",
  "Mystery",
  "Programming",
  "Horror",
  "Science Fiction",
  "Fantasy",
  "Bibliography",
  "Autobiography",
  "History",
  "Romance",
  "LGBTQ+",
  "Manga",
  "Novels",
  "Sports",
  "Self-help",
  "Business",
  "Education",
  "Children Books",
  "Travel",
  "Religion",
  "Art and Design"
]

const [selectedBookCategory, setSelectedBookCategory] = useState(bookCategory[0])

const handleChangeSelectedValue = (e) =>{
    // console.log(e.target.value);
    setSelectedBookCategory(e.target.value)
}

// handle book submission
const handleSubmit = (e) =>{
e.preventDefault();
const form = e.target;

const bookTitle = form.bookTitle.value;
const authorName = form.authorName.value;
const imageURL = form.imageURL.value;
const category = form.categoryName.value;
const bookDescription = form.bookDescription.value;
const shoplink = form.shoplink.value;
const readlink = form.readlink.value;

const bookObject = {
  bookTitle, authorName, imageURL, category, bookDescription,  shoplink, readlink
}

// send to database
fetch("http://localhost:5000/upload-book", {
    method: "POST",
    headers: {
      "Content-type": "application/json"
    },
    body: JSON.stringify(bookObject)
  })
  .then(res => res.json())
  .then(data => {
    console.log(data);
    alert("Book Uploaded Successfully...");
    // Reset the form
    form.reset();
  })
  .catch(error => {
    console.error('Error:', error);
    alert("Failed to upload book. Please try again later.");
  });
}

  return (
    <div className="px-4 my-12">
      <h2 className="mb-8 text-3xl font-bold">Upload A Book</h2>

      <form onSubmit={handleSubmit} className="flex lg:w-[1180px] flex-col flex-wrap gap-4">
        {/* first row */}
        <div className="flex gap-8">
          {/* book title */}
          <div className="lg:w-1/2">
          <div className="mb-2 block">
            <Label 
            htmlFor="bookTitle" 
            value="Book Title" />
          </div>
          <TextInput 
          id="bookTitle"
          name="bookTitle" 
          type="text" 
          placeholder="Book Name" 
          required />
          </div>
          {/* book author */}
          <div className="lg:w-1/2">
          <div className="mb-2 block">
            <Label 
            htmlFor="authorName" 
            value="Book Author" />
          </div>
          <TextInput 
          id="authorName"
          name="authorName" 
          type="text" 
          placeholder="Author Name" 
          required />
          </div>
        </div>

        {/* second row */}
        <div className="flex gap-8">
          {/* image url */}
          <div className="lg:w-1/2">
          <div className="mb-2 block">
            <Label 
            htmlFor="imageURL" 
            value="Book Image URL" />
          </div>
          <TextInput 
          id="imageURL"
          name="imageURL" 
          type="text" 
          placeholder="Book Image URL" 
          required />
          </div>
          {/* Category */}
          <div className="lg:w-1/2">
          <div className="mb-2 block">
            <Label 
            htmlFor="inputState" 
            value="Book Category" />
          </div>
          <select name="categoryName" id="inputState" className="w-full rounded" value={selectedBookCategory} onChange={handleChangeSelectedValue}>
            {
                bookCategory.map((option)=><option key={option} value={option}>{option}</option>)
                
            }
          </select>
          </div>
        </div>

        {/* 3rd row */}
        {/* book description */}
        <div>
        <div className="mb-2 block">
          <Label 
          htmlFor="bookDescription" 
          value="Book Description..." />
        </div>
        <Textarea 
        id="bookDescription"
        name="bookDescription"
        placeholder="Book Description"
        className="w-full" 
        rows={6} />
        </div>

        {/* 4th row */}
        <div className="flex gap-8">
          {/* shop link */}
          <div className="lg:w-1/2">
          <div className="mb-2 block">
            <Label 
            htmlFor="shoplink" 
            value="Shopping Link" />
          </div>
          <TextInput 
          id="shoplink"
          name="shoplink" 
          type="text" 
          placeholder="Shopping Link" 
          required />
          </div>
          {/* read link */}
          <div className="lg:w-1/2">
          <div className="mb-2 block">
            <Label 
            htmlFor="readlink" 
            value="Read Link" />
          </div>
          <TextInput 
          id="readlink"
          name="readlink" 
          type="text" 
          placeholder="Online reading link" 
          required />
          </div>
        </div>

        {/* button for submit */}
        <Button type="submit" className="mt-5">
          Upload Book
        </Button>
            
    </form>

    </div>
  )
}

export default UploadBook

