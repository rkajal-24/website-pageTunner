// import React from 'react'

const Doc = () => {
    return (
        <div className="m-6 font-serif border border-solid border-black">
        <div className="px-8 pt-14">
       <h1 className="p-6 pt-10 text-center font-bold text-3xl"> Documentation </h1>

   <h1 className="underline">Last updated: [03-03-2024]</h1>

 <p>PageTunner operates. This page informs you of our policies regarding the collection, use, and disclosure of Personal Information we receive from users of the Site.

We use your Personal Information only for providing and improving the Site. By using the Site, you agree to the collection and use of information in accordance with this policy.</p>

<p>While using our Site, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. Personally identifiable information may include, but is not limited to your name Personal Information.</p>


<p>We may use your Personal Information to contact you with newsletters, marketing or promotional materials and other information that pertains to our services. You can opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>

<p>Cookies are files with small amount of data, which may include an anonymous unique identifier. Cookies are sent to your browser from a web site and stored on your computers hard drive. Like many sites, we use cookies to collect information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Site.</p>

<p>The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>

<p>This Privacy Policy is effective as of [Date] and will remain in effect except with respect to any changes in its provisions in the future, which will be in effect immediately after being posted on this page.</p>

<p>We reserve the right to update or change our Privacy Policy at any time and you should check this Privacy Policy periodically. Your continued use of the Service after we post any modifications to the Privacy Policy on this page will constitute your acknowledgment of the modifications and your consent to abide and be bound by the modified Privacy Policy.</p>

 <p>PageTunner operates. This page informs you of our policies regarding the collection, use, and disclosure of Personal Information we receive from users of the Site.

We use your Personal Information only for providing and improving the Site. By using the Site, you agree to the collection and use of information in accordance with this policy.</p>


<p>While using our Site, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. Personally identifiable information may include, but is not limited to your name Personal Information.</p>


<p>Like many site operators, we collect information that your browser sends whenever you visit our Site Log Data. This Log Data may include information such as your computers Internet Protocol IP address, browser type, browser version, the pages of our Site that you visit, the time and date of your visit, the time spent on those pages and other statistics.</p>

<p>We may use your Personal Information to contact you with newsletters, marketing or promotional materials and other information that pertains to our services. You can opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>

<p>Cookies are files with small amount of data, which may include an anonymous unique identifier. Cookies are sent to your browser from a web site and stored on your computers hard drive. Like many sites, we use cookies to collect information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Site.</p>

<p>The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>

<p className="pb-12">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Atque, deleniti! Quis suscipit fugit rerum nemo vero, qui voluptas sed ipsam facere natus, sit aperiam reiciendis enim aliquid similique neque est iusto architecto ex, ipsum perferendis! Voluptatem ipsa molestiae facilis rerum odio doloremque iusto iste. Beatae aspernatur modi quisquam autem ex molestias dolorum facilis ducimus, fuga dolorem excepturi vel architecto ipsum qui debitis nobis doloremque magnam minus cum! Laboriosam consequatur necessitatibus qui quibusdam saepe at dolor? Quos recusandae reprehenderit fugiat tenetur tempora magni sit cupiditate reiciendis nesciunt molestias. Illum, unde fugit iusto blanditiis ad repellat minima officia quis nisi error, fuga facilis! Quos, temporibus? A, illum animi. Atque perspiciatis quo assumenda odit possimus, eos fugit esse, maxime, veritatis consectetur optio amet officiis in. Aspernatur dolorum dolorem, suscipit sit consequuntur nemo quis. Quasi consequatur excepturi molestias, enim fugit assumenda atque eius consequuntur quia. Neque ipsa natus reiciendis quas alias sed, voluptatibus sequi harum error sapiente magni, minima id quos temporibus omnis. Provident ut illo sequi libero? Unde inventore blanditiis quod similique nam iste vero eos fuga a accusamus animi nisi soluta, eius magni odio, odit voluptatum ex iure, molestiae dicta explicabo aspernatur repellendus quisquam! Cum porro ipsum alias nihil dolorem accusantium tenetur.</p>


    </div>
    
</div>
    )
  }
  
  export default Doc