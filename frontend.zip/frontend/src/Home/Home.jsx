// import React from 'react'

import Banner from "../components/Banner"
import BestSellerBooks from "./BestSellBook"
import ExploreSection from "./ExploreSection"
import Otherbook from "./Otherbook"
import PromoBanner from "./PromoBanner"
import Review from "./Review"


const Home = () => {
  return (
    <div>
    <Banner/>
    <BestSellerBooks/>
    <ExploreSection/>
    <PromoBanner/>
    <Otherbook/>
    <Review/>
    </div>
   
  )
}

export default Home
