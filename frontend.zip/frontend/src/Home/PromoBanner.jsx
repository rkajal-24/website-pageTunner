// import React from 'react'

import { Link } from "react-router-dom"
import bookPromo from "../assets/promobook.png"

const PromoBanner = () => {
  return (
    <div className="mt-16 py-12 px-4 bg-gradient-to-l from-teal-300 to-teal-100 lg:px24">
      <div className="flex flex-col md:flex-row justify-between items-center gap-12">
        <div className="md:w-1/2">
          <h2 className="text-4xl font-bold mb-6 leading-snug">2024 National Book Award for Fiction Shortlist</h2>
        
          <Link to="/Shop" className="block"><button className="bg-blue-600 hover:bg-black text-white py-2 px-5 font-semibold rounded transition-all duration-300">Get Promo Code</button></Link>
        </div>
        <div>
          <img src={bookPromo} alt="" className="w-96" />
        </div>
      </div>
    </div>
  )
}

export default PromoBanner
