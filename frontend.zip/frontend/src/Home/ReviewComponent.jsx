// import React from 'react'
import {FaStar} from "react-icons/fa6"
import { Avatar } from "flowbite-react";
import profile from '../assets/person1.jpg'

const ReviewComponent = () => {
  return (
    <div className='space-y-6'>
                <div className='text-amber-500 flex gap-2'>
                    <FaStar/>
                    <FaStar/>
                    <FaStar/>
                    <FaStar/>
                </div>
                {/* text */}
                <div className='mt-7'>
                    <p className='mb-5'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi dicta quis magnam adipisci quaerat, est aut hic et odit mollitia.</p>
                    <Avatar img={profile} alt="avatar of Jese" rounded className='w-10 mb-4'/>
                    <h5 className='text-lg font-medium'>Merry Rose</h5>
                    <p className='text-base'>CEO, ABC company</p>
                </div>
            </div>
           
  )
}

export default ReviewComponent
