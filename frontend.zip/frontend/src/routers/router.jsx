import { createBrowserRouter, } from "react-router-dom";
import App from "../App";
import Home from "../Home/Home";
import Shop from "../Shop/Shop";
import About from "../components/About";
import Blog from "../components/Blog";
import SingleBook from "../Shop/SingleBook";
import Dashboard from "../dashboard/Dashboard";
import Dashboard2 from "../dashboard/Dashboard2";
import UploadBook from "../dashboard/UploadBook";
import ManageBook from "../dashboard/ManageBook";
import EditBook from "../dashboard/EditBook";
import SignUp from "../components/SignUp";
import Login from "../components/Login";
import PrivateRoute from "../PrivateRouting/PrivateRoute";
import Logout from "../components/Logout";
import PrivacyPolicy from "../components/PrivacyPolicy";
import Help from "../dashboard/Help";
import Doc from "../dashboard/Doc";

  const router = createBrowserRouter([
    // front part
    {
      path: "/",
      element: <App/>,
      children: [
        {
        path: '/',
        element: <Home/>
        },
        {
          path: '/Shop',
          element: <Shop/>
          },
          {
            path: '/About',
            element: <About/>
            },
            {
              path: '/Blog',
              element: <Blog/>
              },
             
              {
                path: '/book/:id',
                element: <SingleBook/>,
                loader:({params}) => fetch(`http://localhost:5000/book/${params.id}`)
                },
      ]
    }, 

     // footer link privacy policy page
     {
      path: '/PrivacyPolicy',
      element: <PrivacyPolicy/>
      },
    // dashboard part
    {
      path: "/admin/dashboard",
      element: <Dashboard/>,
      children: [
        {
        path: "/admin/dashboard",
        element: <PrivateRoute><Dashboard2/></PrivateRoute>
        },
        {
          path: "/admin/dashboard/upload",
          element: <UploadBook/>
          },
          {
            path: "/admin/dashboard/manage",
            element: <ManageBook/>
            },
            {
              path: "/admin/dashboard/edit-book/:id",
              element: <EditBook/>,
              loader:({params}) => fetch(`http://localhost:5000/book/${params.id}`)
              },  
              
      ]
    },
    // Sign-Up ang Login part
    {
      path: 'sign-up',
      element: <SignUp/> 
    },
    {
      path: 'login',
      element: <Login/> 
    },
    {
      path: 'logout',
      element: <Logout/> 
    },
    {
      path: 'doc',
      element: <Doc/> 
    },
    {
      path: 'help',
      element: <Help/> 
    }

  ]);

  export default router;