// import React from 'react'
// import Banner from './Banner';


const Blog = () => {
  
  return (
    <div className=" bg-teal-100">
     <div className="py-8 sm:py-12 dark:bg-gray-100 dark:text-gray-800">
	<div className="container p-6 mx-auto space-y-8">
		<div className="space-y-2 text-center">
			<h2 className="text-3xl font-bold">Between the Pages: A Book Lovers Blog</h2>
			<p className="font-serif text-sm dark:text-gray-600">Welcome to our book blog, where the magic of literature comes alive!</p>
		</div>
		<div className="grid grid-cols-1 gap-x-4 gap-y-8 md:grid-cols-2 lg:grid-cols-4">

			{/* 1st blog */}
			<div className="flex flex-col dark:bg-gray-50">
				<img alt="" className="object-cover w-full h-52 sm:h-4/5  dark:bg-gray-500" src="https://th.bing.com/th/id/OIP.rI3t5rMiQp6lHGDhH8hLQwHaF7?rs=1&pid=ImgDetMain/200x200" />
				<div className="flex flex-col flex-1 p-6">
					<p className="text-xs tracking-wider uppercase hover:underline dark:text-violet-600">Tulip Flower</p>
					<h3 className="flex-1 py-2 text-lg font-semibold leading-snug">Flowers in Focus: Exquisite Photography of Natures Floral Gems</h3>
					<div className="flex flex-wrap justify-between pt-3 space-x-2 text-xs dark:text-gray-600">
					<span>June 1, 2023</span>
					<span>2.1K views</span>
				</div>
				</div>
			</div>


			{/* 2nd blog */}
			<div className="flex flex-col dark:bg-gray-50">
				<img alt="" className="object-cover w-full h-52 sm:h-4/5  dark:bg-gray-500" src="https://th.bing.com/th/id/R.2e5490e55cf1e02d3d5279b827ff0655?rik=aYLbuy%2bkwcLyew&riu=http%3a%2f%2fs1.picswalls.com%2fwallpapers%2f2015%2f12%2f12%2fbeautiful-images_124416758_294.jpg&ehk=QPrUdFKVHEqxgMkxkUrkqedjwGqL2tH%2fBtQ46tQ%2fMF0%3d&risl=&pid=ImgRaw&r=0/200x200" />
				<div className="flex flex-col flex-1 p-6">
					<p className="text-xs tracking-wider uppercase hover:underline dark:text-violet-600">Clouds</p>
					<h3 className="flex-1 py-2 text-lg font-semibold leading-snug">Botanical Brilliance: Celebrating the Diversity of Flowers</h3>
					<div className="flex flex-wrap justify-between pt-3 space-x-2 text-xs dark:text-gray-600">
					<span>June 1, 2023</span>
					<span>1.3K views</span>
				</div>
				</div>
			</div>

			{/* 3rd blog */}
			<div className="flex flex-col dark:bg-gray-50">
				<img alt="" className="object-cover w-full h-52 sm:h-4/5  dark:bg-gray-500" src="https://th.bing.com/th/id/R.8909a6687c8c7317c56c91af88a3982b?rik=YbjdcBzi%2fyN0GA&riu=http%3a%2f%2f3.bp.blogspot.com%2f-2_uQf67bInA%2fUAFQxIwX8qI%2fAAAAAAAAAC4%2fG7mqOd8glAA%2fs1600%2fNature_Flowers_Beautiful_flowers.jpg&ehk=pNKZYF52U3JWJro%2f7i2dEwjB%2bJY0K8IXepW8Z0c82GE%3d&risl=&pid=ImgRaw&r=0/200x200" />
				<div className="flex flex-col flex-1 p-6">
					<p className="text-xs tracking-wider uppercase hover:underline font-semibold"> White Nature</p>
					<h3 className="flex-1 py-2 text-lg font-semibold leading-snug">Blossoms and Blooms: Exploring the World of Flowers</h3>
					<div className="flex flex-wrap justify-between pt-3 space-x-2 text-xs dark:text-gray-600">
					<span>June 1, 2023</span>
					<span>2.1K views</span>
				</div>
				</div>
			</div>

			{/* 4th blog */}
			<div className="flex flex-col dark:bg-gray-50">
				<img alt="" className="object-cover w-full h-52 sm:h-4/5 dark:bg-gray-500" src="https://th.bing.com/th/id/R.6ae0f9ba7af6c5d160f533417df3a785?rik=pUm%2fOgkv7qXSdQ&riu=http%3a%2f%2fgetwallpapers.com%2fwallpaper%2ffull%2f5%2fc%2fc%2f1036834-motivational-desktop-backgrounds-1920x1440-for-iphone-7.jpg&ehk=tMkYzI02WMgFroNxmuS%2bsRo8IVzGJ36cFUDP67LAnME%3d&risl=&pid=ImgRaw&r=0/200x200" />
				<div className="flex flex-col flex-1 p-6">
					<p className="text-xs tracking-wider uppercase hover:underline font-semibold">Quotes Lovers</p>
					<h3 className="flex-1 py-2 text-lg font-semibold leading-snug">Unveiling Earths Treasures: The Magic of Nature</h3>
					<div className="flex flex-wrap justify-between pt-3 space-x-2 text-xs dark:text-gray-600">
					<span>Jan 1, 2023</span>
					<span>1.5K views</span>
				</div>
				</div>
			</div>

			{/* 5th blog */}
			<div className="flex flex-col dark:bg-gray-50">
				<img alt="" className="object-cover w-full h-52 sm:h-4/5  dark:bg-gray-500" src="https://th.bing.com/th/id/OIF.nUIUQLk2GDYi9ZNjZrixBw?rs=1&pid=ImgDetMain/200x200" />
				<div className="flex flex-col flex-1 p-6">
					<p className="text-xs tracking-wider uppercase hover:underline font-semibold">Animal</p>
					<h3 className="flex-1 py-2 text-lg font-semibold leading-snug">Natures Canvas: Painting with Earths Elements</h3>
					<div className="flex flex-wrap justify-between pt-3 space-x-2 text-xs dark:text-gray-600">
					<span>March 1, 2024</span>
					<span>2.1K views</span>
				</div>
				</div>
			</div>

			{/* 6th blog */}
			<div className="flex flex-col dark:bg-gray-50">
				<img alt="" className="object-cover w-full h-52 sm:h-4/5  dark:bg-gray-500" src="https://th.bing.com/th/id/OIP.q8AT3F4pC-4t0n0lnfp7xgHaE8?rs=1&pid=ImgDetMain/200x200" />
				<div className="flex flex-col flex-1 p-6">
					<p className="text-xs tracking-wider uppercase hover:underline font-semibold">Sports</p>
					<h3 className="flex-1 py-2 text-lg font-semibold leading-snug">In the Arena: A Dive into the World of Competitive Sports</h3>
					<div className="flex flex-wrap justify-between pt-3 space-x-2 text-xs dark:text-gray-600">
					<span>Feb 1, 2024</span>
					<span>1K views</span>
				</div>
				</div>
			</div>

			{/* 7th blog */}
			<div className="flex flex-col dark:bg-gray-50">
				<img alt="" className="object-cover w-full h-52 sm:h-4/5  dark:bg-gray-500" src="https://th.bing.com/th/id/R.cc9141e26719a2ec259c477984b33eb8?rik=N02PlTEUfMXzIg&riu=http%3a%2f%2feskipaper.com%2fimages%2fbeautiful-art-wallpaper-1.jpg&ehk=DM30yB7462OPDZi9rLe%2fYPNaHwupwj8yHMp2%2bHhzLKE%3d&risl=&pid=ImgRaw&r=0/200x200" />
				<div className="flex flex-col flex-1 p-6">
					<p className="text-xs tracking-wider uppercase hover:underline font-semibold">Wolf Night</p>
					<h3 className="flex-1 py-2 text-lg font-semibold leading-snug">Wonders of the Natural World: Beauty Beyond Boundaries</h3>
					<div className="flex flex-wrap justify-between pt-3 space-x-2 text-xs dark:text-gray-600">
					<span>June 1, 2023</span>
					<span>3.1K views</span>
				</div>
				</div>
			</div>

			{/* 8th blog */}
			<div className="flex flex-col dark:bg-gray-50">
				<img alt="" className="object-cover w-full h-52 sm:h-4/5  dark:bg-gray-500" src="https://th.bing.com/th/id/R.fae89b527e7bb7ed46d30a13e0d916f1?rik=cyw0BMbHBKs1eQ&riu=http%3a%2f%2f3.bp.blogspot.com%2f-KYxDxCdF48w%2fUnz31zMorsI%2fAAAAAAAACtw%2fMvWd7RI9B7o%2fs1600%2fbeautiful%2bbutterfly%2bwallpapers-7.jpg&ehk=P%2bZP91G9U46MK9P3A5kbCka2TiV0kcwi%2bwdi%2bN3lkeQ%3d&risl=&pid=ImgRaw&r=0/200x200" />
				<div className="flex flex-col flex-1 p-6">
					<p className="text-xs tracking-wider uppercase hover:underline font-semibold">Butterfly</p>
					<h3 className="flex-1 py-2 text-lg font-semibold leading-snug">The Majesty of Nature: Exploring Earths Wonders</h3>
					<div className="flex flex-wrap justify-between pt-3 space-x-2 text-xs dark:text-gray-600">
					<span>Feb 1, 2023</span>
					<span>1.5K views</span>
				</div>
				</div>
			</div>
		</div>
	</div>
</div>
    </div>
  )
}

export default Blog;
