// import React from 'react'

const About = () => {
  return (
    <div className=" bg-teal-100 font-serif">
        <div className="p-8 py-14">
       <h1 className="p-6 pt-10 text-center font-bold text-5xl"> About Us</h1>

 <p className="mb-4 font-semibold">Welcome to our website! We are a team of passionate individuals dedicated to providing high-quality products/services to our customers.</p>

 <hr className="border-t border-gray-800 pb-2"/>

<p className="mb-4">In our About Us page, you will learn more about our mission, vision, team, and values. Feel free to reach out to us if you have any questions or inquiries!</p>

<p className="mb-4">Like many site operators, we collect information that your browser sends whenever you visit our Site Log Data. This Log Data may include information such as your computers Internet Protocol IP address, browser type, browser version, the pages of our Site that you visit, the time and date of your visit, the time spent on those pages and other statistics.
We may use your Personal Information to contact you with newsletters, marketing or promotional materials and other information that pertains to our services. You can opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>

<p className="mb-4">Cookies are files with small amount of data, which may include an anonymous unique identifier. Cookies are sent to your browser from a web site and stored on your computers hard drive. Like many sites, we use cookies to collect information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Site.</p>

<p className="mb-4">The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>

<p className="mb-4">Like many site operators, we collect information that your browser sends whenever you visit our Site Log Data. This Log Data may include information such as your computers Internet Protocol IP address, browser type, browser version, the pages of our Site that you visit, the time and date of your visit, the time spent on those pages and other statistics.
We may use your Personal Information to contact you with newsletters, marketing or promotional materials and other information that pertains to our services. You can opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>

<p className="mb-4">The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>

<p className="mb-4">The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>

<p className="mb-4">Like many site operators, we collect information that your browser sends whenever you visit our Site Log Data. This Log Data may include information such as your computers Internet Protocol IP address, browser type, browser version, the pages of our Site that you visit, the time and date of your visit, the time spent on those pages and other statistics.
We may use your Personal Information to contact you with newsletters, marketing or promotional materials and other information that pertains to our services. You can opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>

<p className="mb-4">Like many site operators, we collect information that your browser sends whenever you visit our Site Log Data. This Log Data may include information such as your computers Internet Protocol IP address, browser type, browser version, the pages of our Site that you visit, the time and date of your visit, the time spent on those pages and other statistics.
We may use your Personal Information to contact you with newsletters, marketing or promotional materials and other information that pertains to our services. You can opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>

<p className="mb-4">The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>

<p className="mb-4">The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>


<p className="mb-4">The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>

<p className="mb-4">Like many site operators, we collect information that your browser sends whenever you visit our Site Log Data. This Log Data may include information such as your computers Internet Protocol IP address, browser type, browser version, the pages of our Site that you visit, the time and date of your visit, the time spent on those pages and other statistics.
We may use your Personal Information to contact you with newsletters, marketing or promotional materials and other information that pertains to our services. You can opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>
<hr className="border-t border-gray-800" />
<p className="mb-4 font-sans font-semibold">Thank you for visiting our website. Feel free to explore and learn more about us!</p>


    </div>
    </div>
  )
}

export default About
