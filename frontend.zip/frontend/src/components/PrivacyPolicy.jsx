// import React from 'react'

const PrivacyPolicy = () => {
  return (
    <div className=" bg-teal-100 m-6 font-serif border border-solid border-black">
        <div className="px-8 pt-14">
       <h1 className="p-6 pt-10 text-center font-bold text-3xl"> PRIVACY POLICY</h1>

   <h1 className="underline">Last updated: [03-03-2024]</h1>

 <p>PageTunner operates. This page informs you of our policies regarding the collection, use, and disclosure of Personal Information we receive from users of the Site.

We use your Personal Information only for providing and improving the Site. By using the Site, you agree to the collection and use of information in accordance with this policy.</p>

<h1 className="pt-3 font-semibold text-2xl">Information Collection and Use</h1>

<p>While using our Site, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. Personally identifiable information may include, but is not limited to your name Personal Information.</p>

<h1 className="pt-3 font-semibold text-2xl">Log Data</h1>

<p>Like many site operators, we collect information that your browser sends whenever you visit our Site Log Data. This Log Data may include information such as your computers Internet Protocol IP address, browser type, browser version, the pages of our Site that you visit, the time and date of your visit, the time spent on those pages and other statistics.</p>

<h1 className="pt-3 font-semibold text-2xl">Communications</h1>

<p>We may use your Personal Information to contact you with newsletters, marketing or promotional materials and other information that pertains to our services. You can opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>

<h1 className="pt-3 font-semibold text-2xl">Cookies</h1>

<p>Cookies are files with small amount of data, which may include an anonymous unique identifier. Cookies are sent to your browser from a web site and stored on your computers hard drive. Like many sites, we use cookies to collect information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Site.</p>

<h1 className="pt-3 font-semibold text-2xl">Security</h1>

<p>The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>

<h1 className="pt-3 font-semibold text-2xl">Changes to This Privacy Policy</h1>

<p>This Privacy Policy is effective as of [Date] and will remain in effect except with respect to any changes in its provisions in the future, which will be in effect immediately after being posted on this page.</p>

<p>We reserve the right to update or change our Privacy Policy at any time and you should check this Privacy Policy periodically. Your continued use of the Service after we post any modifications to the Privacy Policy on this page will constitute your acknowledgment of the modifications and your consent to abide and be bound by the modified Privacy Policy.</p>

<h1 className="pt-3 font-semibold text-2xl">Contact Us</h1>

<p>If you have any questions about this Privacy Policy, please contact us.</p>

<p>Remember to replace the placeholders such as [Date], [Your Company Name], and [your website URL] with your actual information. Additionally, make sure to tailor the policy to accurately reflect how your website or service collects and uses data. It is always a good idea to consult with legal counsel to ensure your privacy policy complies with relevant laws and regulations.</p>
    </div>


    {/* Licensing */}
    <div className="px-8">
    <h1 className="py-6 mt-4 text-left font-bold text-3xl">Licensing</h1>

 <p>PageTunner operates. This page informs you of our policies regarding the collection, use, and disclosure of Personal Information we receive from users of the Site.

We use your Personal Information only for providing and improving the Site. By using the Site, you agree to the collection and use of information in accordance with this policy.</p>

<h1 className="pt-3 font-semibold text-2xl">Information Collection and Use</h1>

<p>While using our Site, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. Personally identifiable information may include, but is not limited to your name Personal Information.</p>

<h1 className="pt-3 font-semibold text-2xl">Log Data</h1>

<p>Like many site operators, we collect information that your browser sends whenever you visit our Site Log Data. This Log Data may include information such as your computers Internet Protocol IP address, browser type, browser version, the pages of our Site that you visit, the time and date of your visit, the time spent on those pages and other statistics.</p>

<h1 className="pt-3 font-semibold text-2xl">Communications</h1>

<p>We may use your Personal Information to contact you with newsletters, marketing or promotional materials and other information that pertains to our services. You can opt out of receiving any, or all, of these communications from us by following the unsubscribe link or instructions provided in any email we send.</p>

<h1 className="pt-3 font-semibold text-2xl">Cookies</h1>

<p>Cookies are files with small amount of data, which may include an anonymous unique identifier. Cookies are sent to your browser from a web site and stored on your computers hard drive. Like many sites, we use cookies to collect information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Site.</p>

<h1 className="pt-3 font-semibold text-2xl">Security</h1>

<p>The security of your Personal Information is important to us, but remember that no method of transmission over the Internet, or method of electronic storage, is 100% secure. While we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>


    </div>
    

     {/* Terms & Conditions */}
     <div className="px-8 pb-12 ">
     <h1 className="py-6 mt-4  text-left font-bold text-3xl">Terms & Conditions</h1>
     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A ad atque eaque sunt laborum voluptatem voluptates incidunt. Veritatis quo harum, alias dolorem libero reiciendis earum placeat corrupti quidem inventore odit dolores. Unde sequi doloremque exercitationem sapiente dolorum vel nesciunt porro ipsam? Vitae provident, ut nulla expedita inventore odio suscipit, tenetur voluptate, repellat nobis voluptates ad nostrum ipsa qui illo fugit!</p>
     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel doloribus adipisci ipsa? Ea voluptate omnis necessitatibus nam obcaecati libero atque quos asperiores aliquam nesciunt, accusamus eius possimus debitis non doloribus laborum labore adipisci repellat aperiam alias saepe nihil minima quaerat. Qui, placeat quisquam officiis pariatur laudantium aliquid consectetur eaque odio quibusdam tempore minima, suscipit at aspernatur modi fuga ipsa nam assumenda dolore ducimus similique ullam. Consectetur expedita, suscipit nam placeat id molestiae iste doloremque, ex doloribus, iusto nemo facilis corrupti libero. Commodi quaerat quis hic suscipit debitis iste, in itaque numquam impedit fuga minima dolores, voluptates similique praesentium, optio voluptatem!</p>
     </div>
     </div>
  )
}

export default PrivacyPolicy
