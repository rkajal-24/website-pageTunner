// import React from 'react'
import { useLoaderData } from "react-router-dom"

const SingleBook = () => {
    const { bookTitle, imageURL, shoplink, readlink} = useLoaderData();
    const handleClick = () => {
      window.open(shoplink, "_blank");
    };
    const handle2Click = () => {
      window.open(readlink, "_blank");
    };
  return (
  <div className="bg-gradient-to-t from-teal-300 to-teal-100  py-3 ">
    <div className="mt-28 px-4 lg:px-24 ">
        <div className=' flex items-center justify-center'>
        <img src={imageURL} alt='' className='h-screen px-6 pb-6 '/>
                        </div>
     <h2 className="flex text-4xl pt-4 font-bold items-center justify-center ">{bookTitle}</h2>
     <div className=" flex items-center gap-2 justify-center mt-6">
        <button
          onClick={handleClick}
          className=" bg-blue-600 hover:bg-black text-white py-3 px-9 font-bold  rounded"
        >
          Buy Now
        </button>
        <button
          onClick={handle2Click}
          className=" bg-blue-600 hover:bg-black text-white py-3 px-9 font-bold  rounded"
        >
          Read Now
        </button>
        </div>
     
    </div>
    </div>
  )
}

export default SingleBook
